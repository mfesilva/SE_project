package pt.ulisboa.tecnico.learnjava.sibs.operation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import pt.ulisboa.tecnico.learnjava.bank.domain.Bank;
import pt.ulisboa.tecnico.learnjava.bank.domain.Client;
import pt.ulisboa.tecnico.learnjava.bank.domain.Bank.AccountType;
import pt.ulisboa.tecnico.learnjava.bank.exceptions.AccountException;
import pt.ulisboa.tecnico.learnjava.bank.exceptions.BankException;
import pt.ulisboa.tecnico.learnjava.bank.exceptions.ClientException;
import pt.ulisboa.tecnico.learnjava.bank.services.Services;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Completed;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Deposited;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Erro;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Operation;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Sibs;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Withdrawn;
import pt.ulisboa.tecnico.learnjava.sibs.exceptions.OperationException;
import pt.ulisboa.tecnico.learnjava.sibs.exceptions.SibsException;

public class ProcessMethodTest {

		private static final int VALUE = 100;
		private static final String ADDRESS = "Ave.";
		private static final String PHONE_NUMBER = "987654321";
		private static final String NIF = "123456789";
		private static final String LAST_NAME = "Silva";
		private static final String FIRST_NAME = "António";

		private Bank sourceBank;
		private Bank targetBank;
		private Client sourceClient;
		private Client targetClient;
		private Services services;
		private Sibs sibs;
		
		@Before
		public void setUp() throws BankException, AccountException, ClientException {
			this.services = new Services();
			this.sourceBank = new Bank("CGD");
			this.targetBank = new Bank("BPI");
			this.sourceClient = new Client(this.sourceBank, FIRST_NAME, LAST_NAME, NIF, PHONE_NUMBER, ADDRESS, 33);
			this.targetClient = new Client(this.targetBank, FIRST_NAME, LAST_NAME, NIF, PHONE_NUMBER, ADDRESS, 22);
			
			this.sibs = new Sibs(3, new Services());
		}
		
//---------------------------Registered Tests---------------------------
		@Test
		public void withdrawnTrue() throws OperationException, BankException, AccountException, ClientException {
			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
			
			Operation operation = new Operation(sourceIBAN, targetIBAN, VALUE, sibs);
			
			operation.getState().process(operation);
			assertTrue(operation.getState() instanceof Withdrawn); 
			}
		
		@Test
		public void registeredToWithdrawnSucess() throws OperationException, BankException, AccountException, ClientException {
			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
			
			Operation operation = new Operation(sourceIBAN, targetIBAN, VALUE, sibs);
			
			operation.getState().process(operation);
			
			assertEquals(0, services.getAccountByIban(sourceIBAN).getBalance());
			assertEquals(100, services.getAccountByIban(targetIBAN).getBalance());
			
		}
		
		@Test
		public void registeredError() throws BankException, AccountException, ClientException, OperationException {
			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
			
			Operation operation = new Operation(sourceIBAN, targetIBAN, 200, sibs);
			

			operation.getState().process(operation);
			operation.getState().process(operation);
			operation.getState().process(operation);
			operation.getState().process(operation);
			
			assertTrue(operation.getState() instanceof Erro);
		}
		
		
//---------------------------Withdrawn Tests---------------------------

		
		@Test
		public void depositTrue() throws OperationException, BankException, AccountException, ClientException {
			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
			
			Operation operation = new Operation(sourceIBAN, targetIBAN, VALUE, sibs);
			operation.setState(new Withdrawn());
			
			operation.getState().process(operation);
			assertTrue(operation.getState() instanceof Deposited);
		}
		
		@Test
		public void withdrawnToDepositedSucess() throws OperationException, BankException, AccountException, ClientException {
			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
			
			Operation operation = new Operation(sourceIBAN, targetIBAN, VALUE, sibs);
			operation.setState(new Withdrawn());
			
			operation.getState().process(operation);
			
//			assertEquals(0, services.getAccountByIban(sourceIBAN).getBalance());
			assertEquals(200, services.getAccountByIban(targetIBAN).getBalance());
		}
					
		
		@Test
		public void withdrawnError() throws BankException, AccountException, ClientException, OperationException {
			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
			
			Operation operation = new Operation(sourceIBAN, targetIBAN, 200, sibs);
			operation.setState(new Withdrawn());

			operation.getState().process(operation);
			operation.getState().process(operation);
			operation.getState().process(operation);
			operation.getState().process(operation);
			
			assertTrue(operation.getState() instanceof Erro);
		}
	
		
//---------------------------Deposited Tests---------------------------
		
		@Test
		public void completedTrue() throws OperationException, BankException, AccountException, ClientException {
			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
			
			Operation operation = new Operation(sourceIBAN, targetIBAN, VALUE, sibs);
			operation.setState(new Deposited());
			
			operation.getState().process(operation);
			assertTrue(operation.getState() instanceof Completed);
		}
		
		@Test
		public void depositedToCompletedSucess() throws OperationException, BankException, AccountException, ClientException {
			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
			
			Operation operation = new Operation(sourceIBAN, targetIBAN, VALUE, sibs);
			operation.setState(new Deposited());
			
			operation.getState().process(operation);
			
//			assertEquals(0, services.getAccountByIban(sourceIBAN).getBalance());
			assertEquals(98, services.getAccountByIban(sourceIBAN).getBalance());
		}
		
		@Test
		public void depositedError() throws BankException, AccountException, ClientException, OperationException {

			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
				
				Operation operation = new Operation(sourceIBAN, targetIBAN, 200, sibs);
				operation.setState(new Deposited());

				operation.getState().process(operation);
				operation.getState().process(operation);
				operation.getState().process(operation);
				operation.getState().process(operation);
				
				assertTrue(operation.getState() instanceof Erro);
			}


		
		
//---------------------------Completed Tests---------------------------
			
		@Test
		public void completedSucess() throws OperationException, BankException, AccountException, ClientException {
			String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
			String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
			
			Operation operation = new Operation(sourceIBAN, targetIBAN, VALUE, sibs);
			operation.setState(new Completed());
			
			operation.getState().process(operation);
			assertTrue(operation.getState() instanceof Completed);
		}

		
		
		@After
		public void tearDown() {
			Bank.clearBanks();
		}
	}
		
		

