package pt.ulisboa.tecnico.learnjava.sibs.sibs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import pt.ulisboa.tecnico.learnjava.bank.domain.Bank;
import pt.ulisboa.tecnico.learnjava.bank.domain.Client;
import pt.ulisboa.tecnico.learnjava.bank.domain.Bank.AccountType;
import pt.ulisboa.tecnico.learnjava.bank.exceptions.AccountException;
import pt.ulisboa.tecnico.learnjava.bank.exceptions.BankException;
import pt.ulisboa.tecnico.learnjava.bank.exceptions.ClientException;
import pt.ulisboa.tecnico.learnjava.bank.services.Services;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Completed;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Deposited;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Operation;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Sibs;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Withdrawn;
import pt.ulisboa.tecnico.learnjava.sibs.exceptions.OperationException;
import pt.ulisboa.tecnico.learnjava.sibs.exceptions.SibsException;

public class CancelOperationMethodTest {
	
	private static final int VALUE = 100;
	private static final String ADDRESS = "Ave.";
	private static final String PHONE_NUMBER = "987654321";
	private static final String NIF = "123456789";
	private static final String LAST_NAME = "Silva";
	private static final String FIRST_NAME = "António";

	private Bank sourceBank;
	private Bank targetBank;
	private Client sourceClient;
	private Client targetClient;
	private Services services;
	private Sibs sibs;
	private String sourceIBAN;
	private String targetIBAN;

	
	
	@Before
	public void setUp() throws BankException, AccountException, ClientException, OperationException, SibsException {
		this.services = new Services();
		this.sourceBank = new Bank("CGD");
		this.targetBank = new Bank("BPI");
		this.sourceClient = new Client(this.sourceBank, FIRST_NAME, LAST_NAME, NIF, PHONE_NUMBER, ADDRESS, 33);
		this.targetClient = new Client(this.targetBank, FIRST_NAME, LAST_NAME, NIF, PHONE_NUMBER, ADDRESS, 22);
		this.sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
		this.targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
		this.sibs = new Sibs(3, new Services());
		this.sibs.addOperation(sourceIBAN, targetIBAN, VALUE);

	}
	
//---------------------------Registered Tests---------------------------
	@Test
	public void cancelRegisteredTrue() throws OperationException, BankException, AccountException, ClientException, SibsException {

		this.sibs.cancelOperation(0);;
		assertEquals(100, services.getAccountByIban(targetIBAN).getBalance());
		assertEquals(100, services.getAccountByIban(sourceIBAN).getBalance());
	}

//---------------------------Withdrawn Tests---------------------------
	@Test
	public void cancelWithdrawnTrue() throws OperationException, BankException, AccountException, ClientException, SibsException {
		Operation operation = this.sibs.getOperation(0);
		operation.setState(new Withdrawn());
		
		this.sibs.cancelOperation(0);
		assertEquals(100, services.getAccountByIban(targetIBAN).getBalance());
		assertEquals(200, services.getAccountByIban(sourceIBAN).getBalance());
	}
	
	
//---------------------------Deposited Tests---------------------------
	
	@Test
	public void cancelDepositedTrue() throws OperationException, BankException, AccountException, ClientException, SibsException {
		Operation operation = this.sibs.getOperation(0);
		operation.setState(new Deposited());
		
		this.sibs.cancelOperation(0);
		
		assertEquals(0, services.getAccountByIban(targetIBAN).getBalance());
		assertEquals(200, services.getAccountByIban(sourceIBAN).getBalance());
	}
	
	
//---------------------------Completed Tests---------------------------

	@Test
	public void cancelCompletedTrue() throws OperationException, BankException, AccountException, ClientException, SibsException {
		Operation operation = this.sibs.getOperation(0);
		operation.setState(new Completed());
		
		this.sibs.cancelOperation(0);
		
		assertEquals(100, services.getAccountByIban(targetIBAN).getBalance());
		assertEquals(100, services.getAccountByIban(sourceIBAN).getBalance());
	}
	
	
	
	@After
	public void tearDown() {
		Bank.clearBanks();
	}
}
