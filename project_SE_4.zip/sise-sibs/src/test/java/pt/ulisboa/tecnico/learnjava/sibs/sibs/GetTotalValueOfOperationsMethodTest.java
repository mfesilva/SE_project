package pt.ulisboa.tecnico.learnjava.sibs.sibs;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import pt.ulisboa.tecnico.learnjava.bank.services.Services;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Operation;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Sibs;
import pt.ulisboa.tecnico.learnjava.sibs.exceptions.OperationException;
import pt.ulisboa.tecnico.learnjava.sibs.exceptions.SibsException;

public class GetTotalValueOfOperationsMethodTest {
	private static final String TARGET_IBAN = "TargetIban";
	private static final String SOURCE_IBAN = "SourceIban";
	private static final int VALUE = 100;

	private Sibs sibs;
//	private Operation operation;

	@Before
	public void setUp() throws OperationException, SibsException {
		this.sibs = new Sibs(3, new Services());
//		this.sibs.addOperation(SOURCE_IBAN, TARGET_IBAN, VALUE);
//		this.sibs.addOperation(SOURCE_IBAN, TARGET_IBAN, VALUE);
	}
	
//	@Test
//	public void GetNumberOfOperationsMethodTestEmpty() {
////		Integer result = sibs.totalNumberOperation();
////		
////		assertEquals(result, Integer.valueOf(0));
//		
//		assertEquals(this.sibs.getTotalNumberOperation(), 0);
//	}
	
	@Test
	public void TestTotalNumberAddOperations() throws OperationException, SibsException {
		this.sibs.addOperation(SOURCE_IBAN, TARGET_IBAN, VALUE);
		this.sibs.addOperation(SOURCE_IBAN, TARGET_IBAN, VALUE);

		assertEquals(200, this.sibs.getTotalValueOperation());
	}
	
//	@Test
//	public void TestTotalNumberRemoveOperations() throws OperationException, SibsException {
//		this.sibs.removeOperation(0);
//		
//		assertEquals(this.sibs.getTotalNumberOperation(),0);
//	}
//	
	@After
	public void tearDown() {
		this.sibs = null;
	}
	
}


