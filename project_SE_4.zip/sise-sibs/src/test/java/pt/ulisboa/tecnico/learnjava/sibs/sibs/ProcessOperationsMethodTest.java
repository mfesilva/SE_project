package pt.ulisboa.tecnico.learnjava.sibs.sibs;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import pt.ulisboa.tecnico.learnjava.bank.domain.Bank;
import pt.ulisboa.tecnico.learnjava.bank.domain.Client;
import pt.ulisboa.tecnico.learnjava.bank.domain.Bank.AccountType;
import pt.ulisboa.tecnico.learnjava.bank.exceptions.AccountException;
import pt.ulisboa.tecnico.learnjava.bank.exceptions.BankException;
import pt.ulisboa.tecnico.learnjava.bank.exceptions.ClientException;
import pt.ulisboa.tecnico.learnjava.bank.services.Services;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Completed;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Deposited;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Registered;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Sibs;
import pt.ulisboa.tecnico.learnjava.sibs.domain.Withdrawn;
import pt.ulisboa.tecnico.learnjava.sibs.exceptions.OperationException;
import pt.ulisboa.tecnico.learnjava.sibs.exceptions.SibsException;

public class ProcessOperationsMethodTest {
	private static final int VALUE = 100;

	private Bank sourceBank;
	private Bank targetBank;
	private Client sourceClient;
	private Client targetClient;
	private Client sourceClient_2;
	private Client targetClient_2;
	private Client sourceClient_3;
	private Client targetClient_3;
	private Services services;
	private Sibs sibs;
	
	@Before
	public void setUp() throws OperationException, SibsException, BankException, ClientException {
		this.services = new Services();
		this.sourceBank = new Bank("CGD");
		this.targetBank = new Bank("BPI");
		this.sourceClient = new Client(this.sourceBank, "Antonio", "Silva", "123456789", "987654321", "Ave.", 33);
		this.targetClient = new Client(this.targetBank, "Antonio", "Silva", "123456789", "987654321", "Ave.", 22);
		this.sourceClient_2 = new Client(this.sourceBank, "Manuel", "Silva", "123456788", "987654322", "Ave.", 33);
		this.targetClient_2 = new Client(this.targetBank, "Manuel", "Silva", "123456788", "987654322", "Ave.", 22);
		this.sourceClient_3 = new Client(this.sourceBank, "Manuel", "Oliveira", "123456778", "987654312", "Ave.", 33);
		this.targetClient_3 = new Client(this.targetBank, "Manuel", "Oliveira", "123456778", "987654312", "Ave.", 22);
		
		
		this.sibs = new Sibs(3, new Services());
	}
		
	@Test
	public void processOperationsSucess() throws OperationException, SibsException, BankException, AccountException, ClientException {
		String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
		String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
		String sourceIBAN_2 = sourceBank.createAccount(AccountType.CHECKING, sourceClient_2, 100, 0);
		String targetIBAN_2 = targetBank.createAccount(AccountType.CHECKING, targetClient_2, 100, 0);
		String sourceIBAN_3 = sourceBank.createAccount(AccountType.CHECKING, sourceClient_3, 100, 0);
		String targetIBAN_3 = targetBank.createAccount(AccountType.CHECKING, targetClient_3, 100, 0);
		
		this.sibs.addOperation(sourceIBAN, targetIBAN, VALUE);
		this.sibs.addOperation(sourceIBAN_2, targetIBAN_2, VALUE);
		this.sibs.addOperation(sourceIBAN_3, targetIBAN_3, VALUE);
		
		this.sibs.getOperation(1).setState(new Deposited());
		this.sibs.getOperation(2).setState(new Withdrawn());

		this.sibs.processOperations();
		
		assertTrue(this.sibs.getOperation(0).getState() instanceof Withdrawn);
		assertTrue(this.sibs.getOperation(1).getState() instanceof Completed);
		assertTrue(this.sibs.getOperation(2).getState() instanceof Deposited);
	}
	
	
	@Test(expected = OperationException.class)
	public void processOperationsFails() throws BankException, AccountException, ClientException, OperationException, SibsException {
		String sourceIBAN = sourceBank.createAccount(AccountType.CHECKING, sourceClient, 100, 0);
		String targetIBAN = targetBank.createAccount(AccountType.CHECKING, targetClient, 100, 0);
		String sourceIBAN_2 = sourceBank.createAccount(AccountType.CHECKING, sourceClient_2, 100, 0);
		String targetIBAN_2 = targetBank.createAccount(AccountType.CHECKING, targetClient_2, 100, 0);
	
		this.sibs.addOperation(sourceIBAN, targetIBAN, VALUE);
		this.sibs.addOperation(sourceIBAN_2, targetIBAN_2, VALUE);
		
		this.sibs.getOperation(0).setState(new Registered());
		this.sibs.getOperation(1).setState(new Deposited());

		this.sibs.processOperations();
		
	}
	
	@After
	public void tearDown() {
		Bank.clearBanks();
	}
 }
