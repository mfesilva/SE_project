package pt.ulisboa.tecnico.learnjava.sibs.domain;

public class Erro extends State {
	
	@Override
	public void process(Operation wrapper) {
	}

	@Override
	public void cancel(Operation wrapper) {

	}
}
