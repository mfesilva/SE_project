package pt.ulisboa.tecnico.learnjava.sibs.domain;

public class Completed extends State {

	@Override
	public void process(Operation wrapper) {
	}

	@Override
	public void cancel(Operation wrapper) {

	}
}
